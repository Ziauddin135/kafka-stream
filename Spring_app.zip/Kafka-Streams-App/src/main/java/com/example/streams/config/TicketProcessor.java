package com.example.streams.config;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.apache.kafka.streams.processor.Processor;
import org.apache.kafka.streams.processor.ProcessorContext;
import org.json.JSONObject;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.concurrent.ConcurrentTaskScheduler;

public class TicketProcessor implements Processor<String, String> {

	private ProcessorContext context;
	
	TaskScheduler scheduler;

	public TicketProcessor(TaskScheduler scheduler) {
		super();
		this.scheduler = scheduler;
	}

	@Override
	@SuppressWarnings("unchecked")
	public void init(ProcessorContext context) {
		//this.scheduler = new ThreadPoolTaskScheduler();
		this.context = context;
	}

	@Override
	public void punctuate(long timestamp) {
		// this method is deprecated and should not be used anymore
	}

	@Override
	public void close() {
		// close any resources managed by this processor
		// Note: Do not close any StateStores as these are managed by the library
	}

	@Override
	public void process(String key, String value) {
		System.out.println(Thread.currentThread().getName());
		 ScheduledExecutorService localExecutor = Executors.newScheduledThreadPool(6);
		((ConcurrentTaskScheduler)scheduler).setScheduledExecutor(localExecutor);
		try {
			System.out.println("Thread going to sleep>>>"+Thread.currentThread().getName()+" at>"+LocalDateTime.now());
			scheduler.schedule(scheduleJob(value),
					new Date(System.currentTimeMillis() + 30 * 1000));		
			localExecutor.awaitTermination(30, TimeUnit.SECONDS);
			System.out.println("Thread woken up>>"+Thread.currentThread().getName()+" at>"+LocalDateTime.now());
			context.commit();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		

	}

	public Runnable scheduleJob(String ticket) {

		Runnable execute = new Runnable() {
			@Override
			public void run() {
				
				JSONObject jObject = new JSONObject(ticket);
				System.out.println(" ticketNo:"+ticket);
				//System.out.println(" ticketNo:"+jObject.getString("ticketId"));
				
				try {
				} catch (Exception e) {
					// e.printStackTrace();

				}
			}
		};
		return execute;

	}

}