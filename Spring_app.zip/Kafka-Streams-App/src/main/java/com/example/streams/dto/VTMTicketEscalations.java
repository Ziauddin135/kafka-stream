package com.example.streams.dto;

public class VTMTicketEscalations {

}
