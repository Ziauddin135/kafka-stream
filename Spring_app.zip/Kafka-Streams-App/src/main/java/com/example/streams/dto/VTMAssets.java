package com.example.streams.dto;

public class VTMAssets {

}
