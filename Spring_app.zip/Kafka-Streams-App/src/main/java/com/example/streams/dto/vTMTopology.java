package com.example.streams.dto;

public class vTMTopology {

	private String nwID;
	private String nwType;
	public String getNwID() {
		return nwID;
	}
	public void setNwID(String nwID) {
		this.nwID = nwID;
	}
	public String getNwType() {
		return nwType;
	}
	public void setNwType(String nwType) {
		this.nwType = nwType;
	}
	
	
}
