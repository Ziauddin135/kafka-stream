package com.example.streams.dto;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;

//import org.springframework.data.annotation.Id;

//@XmlAccessorType(XmlAccessType.FIELD)
//@XmlRootElement(name = "ticket")
public class Ticket implements Serializable,Cloneable{

	//@Id
    private String id;
	private String ticketNo;
	private String orgBan;
	private String sourceSystem;
	private String source;
	private String functionalArea;
	private String managingOrg;
	private String activeOrg;
	private String endUserEmail;
	private String ticketState;
	private String actionType;
	private String issueType;
	private String ticketType;
	private String ticketStatus;
	private String severity;
	private String priority;
	private String engagementType;
	private String reportedServiceImpact;
	private String reportedRequestType;
	private String reportedServiceLine;
	private String reportedProduct;
	private String reportedTroubleDescription;
	private String reportedTroubleDescription2;
	private String reportedTroubleDescription3;
	private String reportedTroubleDescription4;
	private String reportedCustomerImpact;
	private Date troubleReportedDate;
	private String problemAbstract;
	private String agentID;
	private String workQueue;
	private Date nextCheckTime;
	private String keyItemAffected;
	private String locationID;
	private String lastModifiedBy;
	private Date lastModifiedDate;
	private Date ticketOpenDate;
	private Date ticketClosedDate;
	private Date serviceRestoreDate;
	private boolean locked;
	private String assignedTo;
	private String handoverFlag;
	private String handoverText;
	private String endUserId;
	private String endUserName;
	private String endUserPhone;
	private Object parentTicketNo;
	private Object rootTicketNo;
	private String ticketOwner;
	private String specialNote;
	private String workaround;
	private String mitigation;
	private String restrictionType;
	private String issueDetails;
	private String createdBy;
	private String problem;
	private int roamingIssue;
	private String refTicketNumber;
	private String logType;
	private String logDescription;
	private String engmtType;
	private Date lastCommDate;
	private String lastCommType;
	private String assetID;
	private String callOrigin;
	private String systemUser;
	private String entryType;
	protected String workDone;
	protected String ticketNumber;
	protected String equipmentID;
	protected String ticketSeverity;
	protected String custAffect;
	protected String shortDescription;
	protected String problemCategory;
	protected String problemSubcategory;
	protected String assignedDepartment;
	protected String plannedRestoralTime;
	private Boolean isBusiIP;
	private Boolean isBVOIP;
	private Boolean isChronic;
	private String deviceAff;
	private String addlEmails[];
	private String deviceName;
	private String APN;
	private String modifiedBy;
	private String updatedbySourceSystem;
	
	/***New Field Added For Mission Control */
	
	private String ticketRole;
	private List<VTMEventInfo> vTMEventInfo;
	private VTMRequestInfo vTMRequestInfo;
	
	
	/**********************End of Mission Control**************************************/
	
	

	private String callingSystemName;
	@XmlElement(name = "vTMCustomer")
    private VTMCustomer vTMCustomer;
    private VTMAssets vTMAssets;
    private List<VTMAssociatedTicket> vTMAssociatedTickets;
    
    private VTMTicketEscalations vTMTicketEscalations;
    
    @XmlElement(name = "ticketResolution")
	private TicketResolution ticketResolution;
    
    @XmlElement(name = "logs")
    private List<VTMRefTicketLog> vTMRefTicketLogs;
    
    private List<VTMEngagment> vTMEngagement = new ArrayList<VTMEngagment>();
    
    @XmlElement(name = "vTMRefTicketAttachments")
    private List<DocumentMetadata> documentMetadata;
    
    private Date reqCompletionDate;
    private String notifyPref;
    private String notifyEvent;
    private String refTicketSystem;
    
    private List<vTMQuestionaire>  vTMQuestionaire;
    
    private List<vTMTopology> vTMTopology;
    
    private List<ProductResourceBean> vTMProdResources;
    
    private List<String> servRetProd;
    
    private String contractType;
   
    private Date lastNotifiedDate;
    
    private String totalActiveTime;
	
	
	
	/**For First Net(Salesforce)*/
    private String fan;
    private String userType;
	
	 /**Onetool Field starts**/
    private String eventType;
    private String referenceTicketSystem;
	private VTMContacts vTMContacts;
	private boolean isATTEmp;
	private String pin;
	private List<RelatedTickets> relatedTickets = new ArrayList<RelatedTickets>();
	
	 /**Onetool Fields end**/
    
	public String getOrgBan() {
		return orgBan;
	}

	public void setOrgBan(String orgBan) {
		this.orgBan = orgBan;
	}

	public String getEndUserEmail() {
		return endUserEmail;
	}

	public void setEndUserEmail(String endUserEmail) {
		this.endUserEmail = endUserEmail;
	}

	public String getSourceSystem() {
		return sourceSystem;
	}

	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	public TicketResolution getTicketResolution() {
		return ticketResolution;
	}

	public void setTicketResolution(TicketResolution ticketResolution) {
		this.ticketResolution = ticketResolution;
	}

	public List<VTMRefTicketLog> getVTMRefTicketLogs() {
		return vTMRefTicketLogs;
	}
	
	public List<VTMEngagment> getVTMEngagement() {
		return vTMEngagement;
	}

	public void setvTMEngagement(List<VTMEngagment> vTMEngagement) {
		this.vTMEngagement = vTMEngagement;
	}

	public void setVTMRefTicketLogs(List<VTMRefTicketLog> vTMRefTicketLogs) {
		this.vTMRefTicketLogs = vTMRefTicketLogs;
	}

	public List<DocumentMetadata> getDocumentMetadata() {
		return documentMetadata;
	}

	public void setDocumentMetadata(List<DocumentMetadata> documentMetadata) {
		this.documentMetadata = documentMetadata;
	}

	/**
     * 
     * @return
     *     The Id
     */
    public String getId() {
        return id;
    }

    /**
     * 
     * @param Id
     *     The _id
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * 
     * @return
     *     The ticketNo
     */
    public String getTicketNo() {
        return ticketNo;
    }

    /**
     * 
     * @param ticketNo
     *     The ticketNo
     */
    public void setTicketNo(String ticketNo) {
        this.ticketNo = ticketNo;
    }

    /**
     * 
     * @return
     *     The source
     */
    public String getSource() {
        return source;
    }

    /**
     * 
     * @param source
     *     The source
     */
    public void setSource(String source) {
        this.source = source;
    }

    /**
     * 
     * @return
     *     The functionalArea
     */
    public String getFunctionalArea() {
        return functionalArea;
    }

    /**
     * 
     * @param functionalArea
     *     The functionalArea
     */
    public void setFunctionalArea(String functionalArea) {
        this.functionalArea = functionalArea;
    }

    /**
     * 
     * @return
     *     The managingOrg
     */
    public String getManagingOrg() {
        return managingOrg;
    }

    /**
     * 
     * @param managingOrg
     *     The managingOrg
     */
    public void setManagingOrg(String managingOrg) {
        this.managingOrg = managingOrg;
    }

    /**
     * 
     * @return
     *     The activeOrg
     */
    public String getActiveOrg() {
        return activeOrg;
    }

    /**
     * 
     * @param activeOrg
     *     The activeOrg
     */
    public void setActiveOrg(String activeOrg) {
        this.activeOrg = activeOrg;
    }

    /**
     * 
     * @return
     *     The ticketState
     */
    public String getTicketState() {
        return ticketState;
    }

    /**
     * 
     * @param ticketState
     *     The ticketState
     */
    public void setTicketState(String ticketState) {
        this.ticketState = ticketState;
    }

    /**
     * 
     * @return
     *     The actionType
     */
    public String getActionType() {
        return actionType;
    }

    /**
     * 
     * @param actionType
     *     The actionType
     */
    public void setActionType(String actionType) {
        this.actionType = actionType;
    }

    /**
     * 
     * @return
     *     The issueType
     */
    public String getIssueType() {
        return issueType;
    }

    /**
     * 
     * @param issueType
     *     The issueType
     */
    public void setIssueType(String issueType) {
        this.issueType = issueType;
    }

    /**
     * 
     * @return
     *     The ticketType
     */
    public String getTicketType() {
        return ticketType;
    }

    /**
     * 
     * @param ticketType
     *     The ticketType
     */
    public void setTicketType(String ticketType) {
        this.ticketType = ticketType;
    }

    /**
     * 
     * @return
     *     The ticketStatus
     */
    public String getTicketStatus() {
        return ticketStatus;
    }

    /**
     * 
     * @param ticketStatus
     *     The ticketStatus
     */
    public void setTicketStatus(String ticketStatus) {
        this.ticketStatus = ticketStatus;
    }

    /**
     * 
     * @return
     *     The severity
     */
    public String getSeverity() {
        return severity;
    }

    /**
     * 
     * @param severity
     *     The severity
     */
    public void setSeverity(String severity) {
        this.severity = severity;
    }

    /**
     * 
     * @return
     *     The priority
     */
    public String getPriority() {
        return priority;
    }

    /**
     * 
     * @param priority
     *     The priority
     */
    public void setPriority(String priority) {
        this.priority = priority;
    }

    /**
     * 
     * @return
     *     The engagementType
     */
    public String getEngagementType() {
        return engagementType;
    }

    /**
     * 
     * @param engagementType
     *     The engagementType
     */
    public void setEngagementType(String engagementType) {
        this.engagementType = engagementType;
    }

    /**
     * 
     * @return
     *     The reportedServiceImpact
     */
    public String getReportedServiceImpact() {
        return reportedServiceImpact;
    }

    /**
     * 
     * @param reportedServiceImpact
     *     The reportedServiceImpact
     */
    public void setReportedServiceImpact(String reportedServiceImpact) {
        this.reportedServiceImpact = reportedServiceImpact;
    }

    /**
     * 
     * @return
     *     The reportedRequestType
     */
    public String getReportedRequestType() {
        return reportedRequestType;
    }

    /**
     * 
     * @param reportedRequestType
     *     The reportedRequestType
     */
    public void setReportedRequestType(String reportedRequestType) {
        this.reportedRequestType = reportedRequestType;
    }

    /**
     * 
     * @return
     *     The reportedServiceLine
     */
    public String getReportedServiceLine() {
        return reportedServiceLine;
    }

    /**
     * 
     * @param reportedServiceLine
     *     The reportedServiceLine
     */
    public void setReportedServiceLine(String reportedServiceLine) {
        this.reportedServiceLine = reportedServiceLine;
    }

    /**
     * 
     * @return
     *     The reportedProduct
     */
    public String getReportedProduct() {
        return reportedProduct;
    }

    /**
     * 
     * @param reportedProduct
     *     The reportedProduct
     */
    public void setReportedProduct(String reportedProduct) {
        this.reportedProduct = reportedProduct;
    }

    /**
     * 
     * @return
     *     The reportedTroubleDescription
     */
    public String getReportedTroubleDescription() {
        return reportedTroubleDescription;
    }

    /**
     * 
     * @param reportedTroubleDescription
     *     The reportedTroubleDescription
     */
    public void setReportedTroubleDescription(String reportedTroubleDescription) {
        this.reportedTroubleDescription = reportedTroubleDescription;
    }

    /**
     * 
     * @return
     *     The reportedCustomerImpact
     */
    public String getReportedCustomerImpact() {
        return reportedCustomerImpact;
    }

    /**
     * 
     * @param reportedCustomerImpact
     *     The reportedCustomerImpact
     */
    public void setReportedCustomerImpact(String reportedCustomerImpact) {
        this.reportedCustomerImpact = reportedCustomerImpact;
    }



    /**
     * 
     * @return
     *     The problemAbstract
     */
    public String getProblemAbstract() {
        return problemAbstract;
    }

    /**
     * 
     * @param problemAbstract
     *     The problemAbstract
     */
    public void setProblemAbstract(String problemAbstract) {
        this.problemAbstract = problemAbstract;
    }

    /**
     * 
     * @return
     *     The agentID
     */
    public String getAgentID() {
        return agentID;
    }

    /**
     * 
     * @param agentID
     *     The agentID
     */
    public void setAgentID(String agentID) {
        this.agentID = agentID;
    }

    /**
     * 
     * @return
     *     The workQueue
     */
    public String getWorkQueue() {
        return workQueue;
    }

    /**
     * 
     * @param workQueue
     *     The workQueue
     */
    public void setWorkQueue(String workQueue) {
        this.workQueue = workQueue;
    }



    public Date getNextCheckTime() {
		return nextCheckTime;
	}

	public void setNextCheckTime(Date nextCheckTime) {
		this.nextCheckTime = nextCheckTime;
	}

	/**
     * 
     * @return
     *     The locationID
     */
    public String getLocationID() {
        return locationID;
    }

    /**
     * 
     * @param locationID
     *     The locationID
     */
    public void setLocationID(String locationID) {
        this.locationID = locationID;
    }

    /**
     * 
     * @return
     *     The lastModifiedBy
     */
    public String getLastModifiedBy() {
        return lastModifiedBy;
    }



    public Date getTicketOpenDate() {
		return ticketOpenDate;
	}

	public void setTicketOpenDate(Date ticketOpenDate) {
		this.ticketOpenDate = ticketOpenDate;
	}

	public Date getTroubleReportedDate() {
		return troubleReportedDate;
	}

	public void setTroubleReportedDate(Date troubleReportedDate) {
		this.troubleReportedDate = troubleReportedDate;
	}

	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public Date getTicketClosedDate() {
		return ticketClosedDate;
	}

	public void setTicketClosedDate(Date ticketClosedDate) {
		this.ticketClosedDate = ticketClosedDate;
	}

	public Date getServiceRestoreDate() {
		return serviceRestoreDate;
	}

	public void setServiceRestoreDate(Date serviceRestoreDate) {
		this.serviceRestoreDate = serviceRestoreDate;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

    public String getAssignedTo() {
		return assignedTo;
	}

	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}

	/**
     * 
     * @return
     *     The handoverFlag
     */
    public String getHandoverFlag() {
        return handoverFlag;
    }

    /**
     * 
     * @param handoverFlag
     *     The handoverFlag
     */
    public void setHandoverFlag(String handoverFlag) {
        this.handoverFlag = handoverFlag;
    }

    /**
     * 
     * @return
     *     The handoverText
     */
    public String getHandoverText() {
        return handoverText;
    }

    /**
     * 
     * @param handoverText
     *     The handoverText
     */
    public void setHandoverText(String handoverText) {
        this.handoverText = handoverText;
    }

    /**
     * 
     * @return
     *     The endUserId
     */
    public String getEndUserId() {
        return endUserId;
    }

    /**
     * 
     * @param endUserId
     *     The endUserId
     */
    public void setEndUserId(String endUserId) {
        this.endUserId = endUserId;
    }

    /**
     * 
     * @return
     *     The endUserName
     */
    public String getEndUserName() {
        return endUserName;
    }

    /**
     * 
     * @param endUserName
     *     The endUserName
     */
    public void setEndUserName(String endUserName) {
        this.endUserName = endUserName;
    }

    /**
     * 
     * @return
     *     The endUserPhone
     */
    public String getEndUserPhone() {
        return endUserPhone;
    }

    /**
     * 
     * @param endUserPhone
     *     The endUserPhone
     */
    public void setEndUserPhone(String endUserPhone) {
        this.endUserPhone = endUserPhone;
    }

    /**
     * 
     * @return
     *     The parentTicketNo
     */
    public Object getParentTicketNo() {
        return parentTicketNo;
    }

    /**
     * 
     * @param parentTicketNo
     *     The parentTicketNo
     */
    public void setParentTicketNo(Object parentTicketNo) {
        this.parentTicketNo = parentTicketNo;
    }

    /**
     * 
     * @return
     *     The ticketOwner
     */
    public String getTicketOwner() {
        return ticketOwner;
    }

    /**
     * 
     * @param ticketOwner
     *     The ticketOwner
     */
    public void setTicketOwner(String ticketOwner) {
        this.ticketOwner = ticketOwner;
    }

    /**
     * 
     * @return
     *     The specialNote
     */
    public String getSpecialNote() {
        return specialNote;
    }

    /**
     * 
     * @param specialNote
     *     The specialNote
     */
    public void setSpecialNote(String specialNote) {
        this.specialNote = specialNote;
    }

    /**
     * 
     * @return
     *     The restrictionType
     */
    public String getRestrictionType() {
        return restrictionType;
    }

    /**
     * 
     * @param restrictionType
     *     The restrictionType
     */
    public void setRestrictionType(String restrictionType) {
        this.restrictionType = restrictionType;
    }

    /**
     * 
     * @return
     *     The vTMCustomer
     */
    public VTMCustomer getVTMCustomer() {
        return vTMCustomer;
    }

    /**
     * 
     * @param vTMCustomer
     *     The vTMCustomer
     */
    public void setVTMCustomer(VTMCustomer vTMCustomer) {
        this.vTMCustomer = vTMCustomer;
    }

    /**
     * 
     * @return
     *     The vTMAssets
     */
    public VTMAssets getVTMAssets() {
        return vTMAssets;
    }

    /**
     * 
     * @param vTMAssets
     *     The vTMAssets
     */
    public void setVTMAssets(VTMAssets vTMAssets) {
        this.vTMAssets = vTMAssets;
    }

    /**
     * 
     * @return
     *     The vTMAssociatedTickets
     */
    public List<VTMAssociatedTicket> getVTMAssociatedTickets() {
        return vTMAssociatedTickets;
    }

    /**
     * 
     * @param vTMAssociatedTickets
     *     The vTMAssociatedTickets
     */
    public void setVTMAssociatedTickets(List<VTMAssociatedTicket> vTMAssociatedTickets) {
        this.vTMAssociatedTickets = vTMAssociatedTickets;
    }

    /**
     * 
     * @return
     *     The vTMTicketEscalations
     */
    public VTMTicketEscalations getVTMTicketEscalations() {
        return vTMTicketEscalations;
    }

    /**
     * 
     * @param vTMTicketEscalations
     *     The vTMTicketEscalations
     */
    public void setVTMTicketEscalations(VTMTicketEscalations vTMTicketEscalations) {
        this.vTMTicketEscalations = vTMTicketEscalations;
    }

	public String getKeyItemAffected() {
		return keyItemAffected;
	}

	public void setKeyItemAffected(String keyItemAffected) {
		this.keyItemAffected = keyItemAffected;
	}

	public Object getRootTicketNo() {
		return rootTicketNo;
	}

	public void setRootTicketNo(Object rootTicketNo) {
		this.rootTicketNo = rootTicketNo;
	}

	public String getWorkaround() {
		return workaround;
	}

	public void setWorkaround(String workaround) {
		this.workaround = workaround;
	}

	public String getMitigation() {
		return mitigation;
	}

	public void setMitigation(String mitigation) {
		this.mitigation = mitigation;
	}

	public String getReportedTroubleDescription2() {
		return reportedTroubleDescription2;
	}

	public void setReportedTroubleDescription2(String reportedTroubleDescription2) {
		this.reportedTroubleDescription2 = reportedTroubleDescription2;
	}

	public String getReportedTroubleDescription3() {
		return reportedTroubleDescription3;
	}

	public void setReportedTroubleDescription3(String reportedTroubleDescription3) {
		this.reportedTroubleDescription3 = reportedTroubleDescription3;
	}

	public String getIssueDetails() {
		return issueDetails;
	}

	public void setIssueDetails(String issueDetails) {
		this.issueDetails = issueDetails;
	}

	public boolean isLocked() {
		return locked;
	}

	public void setLocked(boolean locked) {
		this.locked = locked;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getProblem() {
		return problem;
	}

	public void setProblem(String problem) {
		this.problem = problem;
	}

	public int getRoamingIssue() {
		return roamingIssue;
	}

	public void setRoamingIssue(int roamingIssue) {
		this.roamingIssue = roamingIssue;
	}

	public String getRefTicketNumber() {
		return refTicketNumber;
	}

	public void setRefTicketNumber(String refTicketNumber) {
		this.refTicketNumber = refTicketNumber;
	}
	
	public Boolean getIsBusiIP() {
		return isBusiIP;
	}

	public void setIsBusiIP(Boolean isBusiIP) {
		this.isBusiIP = isBusiIP;
	}

	public Boolean getIsBVOIP() {
		return isBVOIP;
	}

	public void setIsBVOIP(Boolean isBVOIP) {
		this.isBVOIP = isBVOIP;
	}

	public Boolean getIsChronic() {
		return isChronic;
	}

	public void setIsChronic(Boolean isChronic) {
		this.isChronic = isChronic;
	}

	public String getDeviceAff() {
		return deviceAff;
	}

	public void setDeviceAff(String deviceAff) {
		this.deviceAff = deviceAff;
	}

	public String[] getAddlEmails() {
		return addlEmails;
	}

	public void setAddlEmails(String[] addlEmails) {
		this.addlEmails = addlEmails;
	}

	public String getDeviceName() {
		return deviceName;
	}

	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}

	public String getAPN() {
		return APN;
	}

	public void setAPN(String aPN) {
		APN = aPN;
	}

	public String getLogType() {
		return logType;
	}

	public void setLogType(String logType) {
		this.logType = logType;
	}

	public String getLogDescription() {
		return logDescription;
	}

	public void setLogDescription(String logDescription) {
		this.logDescription = logDescription;
	}

	public String getEngmtType() {
		return engmtType;
	}

	public void setEngmtType(String engmtType) {
		this.engmtType = engmtType;
	}

	public Date getLastCommDate() {
		return lastCommDate;
	}

	public void setLastCommDate(Date lastCommDate) {
		this.lastCommDate = lastCommDate;
	}

	public String getLastCommType() {
		return lastCommType;
	}

	public void setLastCommType(String lastCommType) {
		this.lastCommType = lastCommType;
	}

	public String getAssetID() {
		return assetID;
	}

	public void setAssetID(String assetID) {
		this.assetID = assetID;
	}

	public String getCallOrigin() {
		return callOrigin;
	}

	public void setCallOrigin(String callOrigin) {
		this.callOrigin = callOrigin;
	}

	public String getSystemUser() {
		return systemUser;
	}

	public void setSystemUser(String systemUser) {
		this.systemUser = systemUser;
	}

	public String getEntryType() {
		return entryType;
	}

	public void setEntryType(String entryType) {
		this.entryType = entryType;
	}

	public VTMCustomer getvTMCustomer() {
		return vTMCustomer;
	}

	public void setvTMCustomer(VTMCustomer vTMCustomer) {
		this.vTMCustomer = vTMCustomer;
	}

	public VTMAssets getvTMAssets() {
		return vTMAssets;
	}

	public void setvTMAssets(VTMAssets vTMAssets) {
		this.vTMAssets = vTMAssets;
	}

	public List<VTMAssociatedTicket> getvTMAssociatedTickets() {
		return vTMAssociatedTickets;
	}

	public void setvTMAssociatedTickets(List<VTMAssociatedTicket> vTMAssociatedTickets) {
		this.vTMAssociatedTickets = vTMAssociatedTickets;
	}

	public VTMTicketEscalations getvTMTicketEscalations() {
		return vTMTicketEscalations;
	}

	public void setvTMTicketEscalations(VTMTicketEscalations vTMTicketEscalations) {
		this.vTMTicketEscalations = vTMTicketEscalations;
	}

	public List<VTMRefTicketLog> getvTMRefTicketLogs() {
		return vTMRefTicketLogs;
	}

	public void setvTMRefTicketLogs(List<VTMRefTicketLog> vTMRefTicketLogs) {
		this.vTMRefTicketLogs = vTMRefTicketLogs;
	}

	public String getWorkDone() {
		return workDone;
	}

	public void setWorkDone(String workDone) {
		this.workDone = workDone;
	}

	public String getTicketNumber() {
		return ticketNumber;
	}

	public void setTicketNumber(String ticketNumber) {
		this.ticketNumber = ticketNumber;
	}

	public String getEquipmentID() {
		return equipmentID;
	}

	public void setEquipmentID(String equipmentID) {
		this.equipmentID = equipmentID;
	}

	public String getTicketSeverity() {
		return ticketSeverity;
	}

	public void setTicketSeverity(String ticketSeverity) {
		this.ticketSeverity = ticketSeverity;
	}

	public String getCustAffect() {
		return custAffect;
	}

	public void setCustAffect(String custAffect) {
		this.custAffect = custAffect;
	}

	public String getShortDescription() {
		return shortDescription;
	}

	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}

	public String getProblemCategory() {
		return problemCategory;
	}

	public void setProblemCategory(String problemCategory) {
		this.problemCategory = problemCategory;
	}

	public String getProblemSubcategory() {
		return problemSubcategory;
	}

	public void setProblemSubcategory(String problemSubcategory) {
		this.problemSubcategory = problemSubcategory;
	}

	public String getAssignedDepartment() {
		return assignedDepartment;
	}

	public void setAssignedDepartment(String assignedDepartment) {
		this.assignedDepartment = assignedDepartment;
	}

	public String getPlannedRestoralTime() {
		return plannedRestoralTime;
	}

	public void setPlannedRestoralTime(String plannedRestoralTime) {
		this.plannedRestoralTime = plannedRestoralTime;
	}

	public Date getReqCompletionDate() {
		return reqCompletionDate;
	}

	public void setReqCompletionDate(Date reqCompletionDate) {
		this.reqCompletionDate = reqCompletionDate;
	}

	public String getNotifyPref() {
		return notifyPref;
	}

	public void setNotifyPref(String notifyPref) {
		this.notifyPref = notifyPref;
	}

	public String getNotifyEvent() {
		return notifyEvent;
	}

	public void setNotifyEvent(String notifyEvent) {
		this.notifyEvent = notifyEvent;
	}

	public List<vTMQuestionaire> getvTMQuestionaire() {
		return vTMQuestionaire;
	}

	public void setvTMQuestionaire(List<vTMQuestionaire> vTMQuestionaire) {
		this.vTMQuestionaire = vTMQuestionaire;
	}

	public List<vTMTopology> getvTMTopology() {
		return vTMTopology;
	}

	public void setvTMTopology(List<vTMTopology> vTMTopology) {
		this.vTMTopology = vTMTopology;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getUpdatedbySourceSystem() {
		return updatedbySourceSystem;
	}

	public void setUpdatedbySourceSystem(String updatedbySourceSystem) {
		this.updatedbySourceSystem = updatedbySourceSystem;
	}

	public String getReportedTroubleDescription4() {
		return reportedTroubleDescription4;
	}

	public void setReportedTroubleDescription4(String reportedTroubleDescription4) {
		this.reportedTroubleDescription4 = reportedTroubleDescription4;
	}

	public List<ProductResourceBean> getvTMProdResources() {
		return vTMProdResources;
	}

	public void setvTMProdResources(List<ProductResourceBean> vTMProdResources) {
		this.vTMProdResources = vTMProdResources;
	}

	public String getRefTicketSystem() {
		return refTicketSystem;
	}

	public void setRefTicketSystem(String refTicketSystem) {
		this.refTicketSystem = refTicketSystem;
	}

	public List<String> getServRetProd() {
		return servRetProd;
	}

	public void setServRetProd(List<String> servRetProd) {
		this.servRetProd = servRetProd;
	}

	public String getCallingSystemName() {
		return callingSystemName;
	}

	public void setCallingSystemName(String callingSystemName) {
		this.callingSystemName = callingSystemName;
	}

	
	
	
	@Override
	public Ticket clone() throws CloneNotSupportedException {
		try {
			final Ticket result = (Ticket) super.clone();
			// copy fields that need to be copied here!
			return result;
		} catch (final CloneNotSupportedException ex) {
			throw new AssertionError();
		}
	}
	public String getContractType() {
		return contractType;
	}
	public void setContractType(String contractType) {
		this.contractType = contractType;
	}
	public List<VTMEngagment> getvTMEngagement() {
		return vTMEngagement;
	}

	public String getTicketRole() {
		return ticketRole;
	}

	public void setTicketRole(String ticketRole) {
		this.ticketRole = ticketRole;
	}

	public Date getLastNotifiedDate() {
		return lastNotifiedDate;
	}

	public void setLastNotifiedDate(Date lastNotifiedDate) {
		this.lastNotifiedDate = lastNotifiedDate;
	}

	public List<VTMEventInfo> getvTMEventInfo() {
		return vTMEventInfo;
	}

	public void setvTMEventInfo(List<VTMEventInfo> vTMEventInfo) {
		this.vTMEventInfo = vTMEventInfo;
	}

	public VTMRequestInfo getvTMRequestInfo() {
		return vTMRequestInfo;
	}

	public void setvTMRequestInfo(VTMRequestInfo vTMRequestInfo) {
		this.vTMRequestInfo = vTMRequestInfo;
	}
	public String getFan() {
		return fan;
	}

	public void setFan(String fan) {
		this.fan = fan;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getTotalActiveTime() {
		return totalActiveTime;
	}

	public void setTotalActiveTime(String totalActiveTime) {
		this.totalActiveTime = totalActiveTime;
	}
	
	/**One tools fields getter setter*/

	public VTMContacts getvTMContacts() {
		return vTMContacts;
	}

	public void setvTMContacts(VTMContacts vTMContacts) {
		this.vTMContacts = vTMContacts;
	}

	public boolean isATTEmp() {
		return isATTEmp;
	}

	public void setATTEmp(boolean isATTEmp) {
		this.isATTEmp = isATTEmp;
	}

	public String getPin() {
		return pin;
	}

	public void setPin(String pin) {
		this.pin = pin;
	}

	public String getReferenceTicketSystem() {
		return referenceTicketSystem;
	}

	public void setReferenceTicketSystem(String referenceTicketSystem) {
		this.referenceTicketSystem = referenceTicketSystem;
	}

	public List<RelatedTickets> getRelatedTickets() {
		return relatedTickets;
	}

	public void setRelatedTickets(List<RelatedTickets> relatedTickets) {
		this.relatedTickets = relatedTickets;
	}

	

	
	
	/***one-tool End*/
	
	
	
}

