package com.example.streams.dto;

import java.beans.Transient;
import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

//@XmlAccessorType(XmlAccessType.FIELD)
//@XmlRootElement(name = "log")
public class VTMRefTicketLog {
	
	private Integer logId;
	private String logType;
	private String logDescription;
	private String logStatus;
	private String createdBy;
	private Date createdDate;
	private String lastModifiedBy;
	private Date lastModifiedDate;
	private String logCommType;
	private String updatedBy;
	private String diagnosticStepPerformed;
	private String systemDiagnosed;
	private String date;
	private String time;
	private String initiatedBy;
	private String diagnosedResult;
	private String extLogSystem;
	private Boolean custLogs;
	private String externalLogSystem;
	
	public String getLogType() {
		return logType;
	}
	public void setLogType(String logType) {
		this.logType = logType;
	}
	public String getLogDescription() {
		return logDescription;
	}
	public void setLogDescription(String logDescription) {
		this.logDescription = logDescription;
	}
	public String getLogStatus() {
		return logStatus;
	}
	public void setLogStatus(String logStatus) {
		this.logStatus = logStatus;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public String getLastModifiedBy() {
		return lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}
	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public String getLogCommType() {
		return logCommType;
	}
	public void setLogCommType(String logCommType) {
		this.logCommType = logCommType;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public String getDiagnosticStepPerformed() {
		return diagnosticStepPerformed;
	}
	public void setDiagnosticStepPerformed(String diagnosticStepPerformed) {
		this.diagnosticStepPerformed = diagnosticStepPerformed;
	}
	public String getSystemDiagnosed() {
		return systemDiagnosed;
	}
	public void setSystemDiagnosed(String systemDiagnosed) {
		this.systemDiagnosed = systemDiagnosed;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getInitiatedBy() {
		return initiatedBy;
	}
	public void setInitiatedBy(String initiatedBy) {
		this.initiatedBy = initiatedBy;
	}
	public String getDiagnosedResult() {
		return diagnosedResult;
	}
	public void setDiagnosedResult(String diagnosedResult) {
		this.diagnosedResult = diagnosedResult;
	}
	public Integer getLogId() {
		return logId;
	}
	public void setLogId(Integer logId) {
		this.logId = logId;
	}
	public String getExtLogSystem() {
		return extLogSystem;
	}
	public void setExtLogSystem(String extLogSystem) {
		this.extLogSystem = extLogSystem;
	}
	public Boolean getCustLogs() {
		return custLogs;
	}
	public void setCustLogs(Boolean custLogs) {
		this.custLogs = custLogs;
	}
	
	public String getExternalLogSystem() {
		return externalLogSystem;
	}
	public void setExternalLogSystem(String externalLogSystem) {
		this.externalLogSystem = externalLogSystem;
	}
	
	
	
}
