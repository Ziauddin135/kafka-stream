/**
 * 
 */
package com.example.streams.dto;

import java.util.Map;

/**
 * @author sa9664
 *
 */
public class RelatedTickets {
	private String sys;
	private String ticketNo;
	private Map<String,String> ascsRefTicketSystemValues;
	public String getSys() {
		return sys;
	}
	public void setSys(String sys) {
		this.sys = sys;
	}
	public String getTicketNo() {
		return ticketNo;
	}
	public void setTicketNo(String ticketNo) {
		this.ticketNo = ticketNo;
	}
	public Map<String, String> getAscsRefTicketSystemValues() {
		return ascsRefTicketSystemValues;
	}
	public void setAscsRefTicketSystemValues(Map<String, String> ascsRefTicketSystemValues) {
		this.ascsRefTicketSystemValues = ascsRefTicketSystemValues;
	}
	
	
	
	

}
