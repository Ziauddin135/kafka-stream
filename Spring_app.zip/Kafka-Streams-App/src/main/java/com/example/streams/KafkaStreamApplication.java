package com.example.streams;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Scope;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.concurrent.ConcurrentTaskScheduler;

import com.example.streams.config.TicketProcessor;

@SpringBootApplication
public class KafkaStreamApplication {

	@Bean
	@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
	public TaskScheduler taskExecutor() {		
		TaskScheduler taskScheduler = new ConcurrentTaskScheduler();
		return taskScheduler;
	}

	@Bean("TicketProcessor")
	@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
	public TicketProcessor getTicketProcessor() {		
		return new TicketProcessor(taskExecutor());
	}
	

	public static void main(String[] args) {
		SpringApplication.run(KafkaStreamApplication.class, args);
	}
}
