package com.example.streams.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.stereotype.Component;

//@Component
//@XmlAccessorType(XmlAccessType.FIELD)
//@XmlRootElement(name = "vTMRefTicketAttachment")
public class DocumentMetadata {
	private String fileName;
	private String attachmentID;
	private String extAttachmentID;
	private String version;
	private String author;
	private String mimeType;
	private String fileSize;
	private String cretatedDate;
	private String description;
	private String previousDocumentVersionID;
	private String lastUpdated;
	private String lastUpdatedBy;
	
	public String getMimeType() {
		return mimeType;
	}
	public void setMimeType(String mimeType) {
		this.mimeType = mimeType;
	}
	public String getPreviousDocumentVersionID() {
		return previousDocumentVersionID;
	}
	public void setPreviousDocumentVersionID(String previousDocumentVersionID) {
		this.previousDocumentVersionID = previousDocumentVersionID;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getAttachmentID() {
		return attachmentID;
	}
	public void setAttachmentID(String attachmentID) {
		this.attachmentID = attachmentID;
	}
	
	public String getExtAttachmentID() {
		return extAttachmentID;
	}
	public void setExtAttachmentID(String extAttachmentID) {
		this.extAttachmentID = extAttachmentID;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	
	public String getFileSize() {
		return fileSize;
	}
	public void setFileSize(String fileSize) {
		this.fileSize = fileSize;
	}
	public String getCretatedDate() {
		return cretatedDate;
	}
	public void setCretatedDate(String cretatedDate) {
		this.cretatedDate = cretatedDate;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getLastUpdated() {
		return lastUpdated;
	}
	public void setLastUpdated(String lastUpdated) {
		this.lastUpdated = lastUpdated;
	}
	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}
	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}
	
	
}
