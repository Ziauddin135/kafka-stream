package com.example.streams;

import java.util.Properties;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.kstream.KStream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.streams.config.AsyncJobLauncher;
import com.example.streams.config.TicketProcessor;

@Component("StreamsConsumer")
public class StreamsConsumer {

    private KafkaStreams streams;
    
    @Autowired
    TicketProcessor ticketProcessor;

	@PostConstruct
	public void runStream() {
		Properties props = new Properties();
		props.put(StreamsConfig.APPLICATION_ID_CONFIG, "StreamsConsumerApplication");
		props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
		props.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass());
		props.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.String().getClass());
		props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
		props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);
		props.put(StreamsConfig.NUM_STREAM_THREADS_CONFIG, 3);
		StreamsBuilder builder = new StreamsBuilder();
		KStream<String, String> printrequest = builder.stream("INPUT_TOPIC_2");		
		try {			
			System.out.println(Thread.currentThread().getName());
			printrequest.process(()-> ticketProcessor);
			printrequest.to(Serdes.String(), Serdes.String(),"OUTPUT_TOPIC_2");
			KafkaStreams streams = new KafkaStreams(builder.build(), props);
			streams.start();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@PreDestroy
	public void closeStream() {
		Runtime.getRuntime().addShutdownHook(new Thread(streams::close));
	}

}
