package com.example.streams;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;
import java.util.Random;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.json.JSONObject;

public class KafkaProducerDemo {

	public static void main(String[] args) {

		// TODO Auto-generated method stub

		Random rand = new Random();

		String receivedJSON = "";

		// "{ \"ticketId\":\"VTM00"++\", \"ticketDelta\":\"\",
		// \"modifiedTicket\":{ \"nextCheckTime\":\"1507926814000\",
		// \"ticketState\":\"Active\", \"priority\":\"Abhishek\" , \"severity\":
		// \"Abhishek\" }, \"session_Worklists\":[ { \"worklistName\":\"ASCS
		// 3.0\", \"updateType\":\"ADD\", \"position\":\"3\",
		// \"sessionId\":\"ddu2gj3g\" } ], \"actionType\":\"CREATE\" }";

		// put in the necessary properties to create the Kafka connection

		Properties props = new Properties();

		props.put("bootstrap.servers", "localhost:9092");

		props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");

		props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");

		props.put("linger.ms", 1);

		JSONObject jsonObject = null;

		// Create a new Kakfa producer

		KafkaProducer<String, String> producer = new KafkaProducer<String, String>(props);

		showTime();
		Calendar cal = Calendar.getInstance();
		for (int i = 0; i < 3; i++) {

			receivedJSON = "{\"ticketId\":" + i + ",\"time\":\"" + cal.getTimeInMillis() + "\","
					+ "\"restcall\":{\"name\": \"morpheus\",\"job\": \"leader\"},\"ticketDelta\":{\"severity\":\"2 - Major\",\"lastModifiedDate\":1517407521727,\"vTMCustomer\":{\"sLO\":\"4\"}},\"modifiedTicket\":{\"ticketState\":\"Active\",\"ticketOpenDate\":1517407232000,\"contractType\":null,\"vTMEngagement\":[],\"serviceRestoreDate\":null,\"ticketResolution\":{\"item\":null,\"prd\":null,\"sRC\":null,\"billingIndicator\":null,\"resolnText\":null,\"resolnItem\":null,\"rC\":null,\"srvComp\":null,\"srvLn\":null,\"srvImpact\":null,\"resolutionSetName\":null,\"clientSatisfied\":null,\"reqType\":null,\"action\":null,\"fa\":\"WIRELESSSVC\"},\"fan\":null,\"problem\":null,\"id\":\"5a71cc380cf23b3705a8f74c\",\"ticketClosedDate\":null,\"agentID\":\"rk713j\",\"mitigation\":null,\"ticketRole\":\"Main\",\"endUserPhone\":\"Unknown\",\"deviceAff\":null,\"priority\":\"Medium\",\"totalActiveTime\":null,\"engmtType\":null,\"restrictionType\":null,\"handoverText\":null,\"reportedCustomerImpact\":null,\"servRetProd\":null,\"workDone\":null,\"endUserId\":\"Unknown\",\"ticketNumber\":null,\"sourceSystem\":null,\"vTMProdResources\":null,\"reqCompletionDate\":null,\"updatedbySourceSystem\":\"VTM\",\"workaround\":null,\"nextCheckTime\":1517409032000,\"ticketSeverity\":null,\"managingOrg\":\"MOBILITY\",\"modifiedBy\":\"RANJAN KUMAR\",\"vTMRefTicketAttachments\":[],\"parentTicketNo\":null,\"logDescription\":null,\"notifyEvent\":null,\"engagementType\":null,\"orgBan\":null,\"lastNotifiedDate\":null,\"handoverFlag\":null,\"callingSystemName\":null,\"vTMTicketEscalations\":{\"lastModifiedTime\":null,\"escalationDeadline\":null,\"escalationStatus\":null,\"escalationBy\":null,\"escalationDate\":null,\"escalationLevel\":null,\"escalationReason\":null},\"locationID\":null,\"vTMRequestInfo\":null,\"vTMCustomer\":{\"accountName\":null,\"clientName\":null,\"companyName\":null,\"sLO3\":\"120\",\"sLO2\":\"4\",\"hotNotes\":null,\"deviceName\":null,\"sLO1\":\"2\",\"fan\":null,\"customerEmail\":null,\"IMSI\":null,\"mcn\":null,\"customerLastName\":null,\"customerAddress\":null,\"customerTelphoneNo\":null,\"IMEINumber\":null,\"notificationEmail\":null,\"BAN\":null,\"customerSIMNumber\":null,\"sourceSys\":null,\"customerFirstName\":null,\"salesForceAccountId\":null,\"sLO\":\"4\",\"customerID\":0,\"userType\":null,\"APN\":null},\"notifyPref\":null,\"endUserName\":\"Unknown\",\"source\":\"vTM\",\"isBVOIP\":null,\"deviceName\":null,\"reportedTroubleDescription\":\"\",\"ticketNo\":\"VTM0080000"+i+"\",\"isBusiIP\":null,\"custAffect\":null,\"keyItemAffected\":null,\"lastCommType\":\"Inbound\",\"problemSubcategory\":null,\"locked\":true,\"rootTicketNo\":null,\"logs\":[{\"logType\":\"customerLogs\",\"date\":null,\"logDescription\":\"PA\",\"logStatus\":null,\"updatedBy\":null,\"lastModifiedDate\":null,\"lastModifiedBy\":null,\"isnew\":null,\"logCommType\":null,\"diagnosticStepPerformed\":null,\"createdDate\":1517407232000,\"custLogs\":null,\"createdBy\":\"rk713j\",\"extLogSystem\":null,\"logId\":null,\"time\":null,\"diagnosedResult\":null,\"systemDiagnosed\":null,\"initiatedBy\":null}],\"callOrigin\":null,\"refTicketSystem\":null,\"entryType\":null,\"reportedRequestType\":\"Fault\",\"ticketOwner\":null,\"shortDescription\":null,\"assignedDepartment\":null,\"issueType\":\"AT&T Messages\",\"isChronic\":null,\"vTMQuestionaire\":null,\"problemAbstract\":\"PA\",\"addlEmails\":null,\"problemCategory\":null,\"functionalArea\":\"WIRELESSSVC\",\"specialNote\":null,\"ticketStatus\":null,\"workQueue\":\"UNKNOWN\",\"userType\":null,\"endUserEmail\":null,\"logType\":\"Engagement\",\"refTicketNumber\":null,\"roamingIssue\":0,\"vTMTopology\":[{\"nwID\":null,\"nwType\":null}],\"reportedServiceLine\":\"MOBILITY\",\"systemUser\":null,\"activeOrg\":\"MOB-ATS\",\"assignedTo\":\"rk713j\",\"vTMAssociatedTickets\":[],\"severity\":\"2 - Major\",\"reportedTroubleDescription4\":null,\"lastModifiedDate\":1517407521727,\"reportedTroubleDescription3\":\"\",\"reportedTroubleDescription2\":\"\",\"lastModifiedBy\":\"rk713j\",\"vTMEventInfo\":null,\"ticketType\":\"User\",\"issueDetails\":null,\"lastCommDate\":null,\"equipmentID\":null,\"reportedServiceImpact\":\"Yes\",\"actionType\":null,\"vTMAssets\":{\"assetLocationState\":null,\"nodeName\":null,\"app\":null,\"eventClass\":null,\"assetStreetAdress\":null,\"zipcd\":null,\"assetLookupType\":null,\"assetLocationCity\":null,\"retrieveAssetInfo\":null,\"assetType\":\"BAN\",\"workFlowId\":null,\"locationID\":null,\"assetLocationCountry\":null,\"deviceModel\":null,\"additionalProperties\":null,\"isVirtual\":null,\"deviceManufacturer\":null,\"assetsId\":\"UNKNOWN\",\"virtualElementType\":null},\"plannedRestoralTime\":null,\"reportedProduct\":null,\"createdBy\":\"Ranjan Kumar\",\"assetID\":null,\"troubleReportedDate\":1517407232000,\"APN\":null},\"session_Worklists\":[{\"worklistName\":\"TestWL_DTTv2\",\"position\":\"1\",\"updateType\":\"NULL\",\"sessionId\":\"NnfG5IgORnLi_wl3QNQ1LssL.zld03286\"}],\"actionType\":\"UPDATE\"}";

			System.out.println(receivedJSON);

			try {

				jsonObject = new JSONObject(receivedJSON);

			} catch (Exception e) {

				e.printStackTrace();

			}

			// Create a random number

			Integer randomnumberone = i;
			

			jsonObject.put("messageId", randomnumberone.toString());

			// produce that random number to the test topic

			producer.send(
					new ProducerRecord<String, String>("INPUT_TOPIC_2", randomnumberone + "", jsonObject.toString()));

		}

		showTime();

		producer.close();

	}

	public static void showTime() {

		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");

		LocalDateTime now = LocalDateTime.now();

		System.out.println(dtf.format(now));

	}

}
