package com.example.streams.dto;

import java.io.Serializable;
import java.util.Date;

public class VTMEventInfo implements Serializable{
	
	private String eventSev;
	private String msgGroup;
	private String msgText;
	
	
	/**OneTool field Start */
	
	private String nineOneOnedispatchCentre;
	private String emergMgrContact;
	private String emergMgr;
	private String addlServ;
	private String servIssue;
	private String emergencyDescription;
	private String onSiteReq;
	private String hundredSqftAvlble;
	private String southernSkyAccess;
	private String securityForAsset;
	private String ownerPermission;
	private String propertyType;
	private String deployCounty;
	private String deployAddr;
	private String deployableType;
	private String dailyTImings;
	private String dataSensitiveAction;
	private String mainReason;
	private String vIPs;
	private String county;
	private String addr;
	private String locName;
	private Date endDate;
	private Date startDate;
	private String desc;
	private String name;
	
	private int fNSubscribers;
	private int eventAttendance;
	
	private String plannedCmdCenter;
	private String cmdCentreLoc;
	private String coverageDeadSpot;
	private String band14DevicesOwnByCust;
	private String deploymentType;

	
	
	/**OneTool field Ends */
	
	public String getEventSev() {
		return eventSev;
	}
	public void setEventSev(String eventSev) {
		this.eventSev = eventSev;
	}
	public String getMsgGroup() {
		return msgGroup;
	}
	public void setMsgGroup(String msgGroup) {
		this.msgGroup = msgGroup;
	}
	public String getMsgText() {
		return msgText;
	}
	public void setMsgText(String msgText) {
		this.msgText = msgText;
	}
	public String getNineOneOnedispatchCentre() {
		return nineOneOnedispatchCentre;
	}
	public void setNineOneOnedispatchCentre(String nineOneOnedispatchCentre) {
		this.nineOneOnedispatchCentre = nineOneOnedispatchCentre;
	}
	public String getEmergMgrContact() {
		return emergMgrContact;
	}
	public void setEmergMgrContact(String emergMgrContact) {
		this.emergMgrContact = emergMgrContact;
	}
	public String getEmergMgr() {
		return emergMgr;
	}
	public void setEmergMgr(String emergMgr) {
		this.emergMgr = emergMgr;
	}
	public String getAddlServ() {
		return addlServ;
	}
	public void setAddlServ(String addlServ) {
		this.addlServ = addlServ;
	}
	public String getServIssue() {
		return servIssue;
	}
	public void setServIssue(String servIssue) {
		this.servIssue = servIssue;
	}
	public String getEmergencyDescription() {
		return emergencyDescription;
	}
	public void setEmergencyDescription(String emergencyDescription) {
		this.emergencyDescription = emergencyDescription;
	}
	public String getOnSiteReq() {
		return onSiteReq;
	}
	public void setOnSiteReq(String onSiteReq) {
		this.onSiteReq = onSiteReq;
	}
	public String getHundredSqftAvlble() {
		return hundredSqftAvlble;
	}
	public void setHundredSqftAvlble(String hundredSqftAvlble) {
		this.hundredSqftAvlble = hundredSqftAvlble;
	}
	public String getSouthernSkyAccess() {
		return southernSkyAccess;
	}
	public void setSouthernSkyAccess(String southernSkyAccess) {
		this.southernSkyAccess = southernSkyAccess;
	}
	public String getSecurityForAsset() {
		return securityForAsset;
	}
	public void setSecurityForAsset(String securityForAsset) {
		this.securityForAsset = securityForAsset;
	}
	public String getOwnerPermission() {
		return ownerPermission;
	}
	public void setOwnerPermission(String ownerPermission) {
		this.ownerPermission = ownerPermission;
	}
	public String getPropertyType() {
		return propertyType;
	}
	public void setPropertyType(String propertyType) {
		this.propertyType = propertyType;
	}
	public String getDeployCounty() {
		return deployCounty;
	}
	public void setDeployCounty(String deployCounty) {
		this.deployCounty = deployCounty;
	}
	public String getDeployAddr() {
		return deployAddr;
	}
	public void setDeployAddr(String deployAddr) {
		this.deployAddr = deployAddr;
	}
	public String getDeployableType() {
		return deployableType;
	}
	public void setDeployableType(String deployableType) {
		this.deployableType = deployableType;
	}
	public String getDailyTImings() {
		return dailyTImings;
	}
	public void setDailyTImings(String dailyTImings) {
		this.dailyTImings = dailyTImings;
	}
	public String getDataSensitiveAction() {
		return dataSensitiveAction;
	}
	public void setDataSensitiveAction(String dataSensitiveAction) {
		this.dataSensitiveAction = dataSensitiveAction;
	}
	public String getMainReason() {
		return mainReason;
	}
	public void setMainReason(String mainReason) {
		this.mainReason = mainReason;
	}
	public String getvIPs() {
		return vIPs;
	}
	public void setvIPs(String vIPs) {
		this.vIPs = vIPs;
	}
	public String getCounty() {
		return county;
	}
	public void setCounty(String county) {
		this.county = county;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public String getLocName() {
		return locName;
	}
	public void setLocName(String locName) {
		this.locName = locName;
	}
	
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getPlannedCmdCenter() {
		return plannedCmdCenter;
	}
	public void setPlannedCmdCenter(String plannedCmdCenter) {
		this.plannedCmdCenter = plannedCmdCenter;
	}
	public String getDeploymentType() {
		return deploymentType;
	}
	public void setDeploymentType(String deploymentType) {
		this.deploymentType = deploymentType;
	}
	
	
	public int getfNSubscribers() {
		return fNSubscribers;
	}
	public void setfNSubscribers(int fNSubscribers) {
		this.fNSubscribers = fNSubscribers;
	}
	public int getEventAttendance() {
		return eventAttendance;
	}
	
	public void setEventAttendance(int eventAttendance) {
		this.eventAttendance = eventAttendance;
	}
	public String getCmdCentreLoc() {
		return cmdCentreLoc;
	}
	public void setCmdCentreLoc(String cmdCentreLoc) {
		this.cmdCentreLoc = cmdCentreLoc;
	}
	public String getCoverageDeadSpot() {
		return coverageDeadSpot;
	}
	public void setCoverageDeadSpot(String coverageDeadSpot) {
		this.coverageDeadSpot = coverageDeadSpot;
	}
	public String getBand14DevicesOwnByCust() {
		return band14DevicesOwnByCust;
	}
	public void setBand14DevicesOwnByCust(String band14DevicesOwnByCust) {
		this.band14DevicesOwnByCust = band14DevicesOwnByCust;
	}
	
	

}
