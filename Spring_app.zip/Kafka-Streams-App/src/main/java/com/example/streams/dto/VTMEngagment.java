package com.example.streams.dto;

import java.io.Serializable;
import java.util.Date;

import javax.xml.datatype.XMLGregorianCalendar;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class VTMEngagment implements Serializable{

	private String ticketNo; 
	private String extSysName;
	private String extSystype;
	private String extTicketNo;
	private String extTicketStatus;
	private String engmtType;
	private Date ticketOpenDate;
	private String internalTicket;
	private Date lastCommDate;
	private String lastCommType;
	private String assetID;
	private String assetType;
	private String salesforceAccountID; //TODO
	private String accAccountID;
	private String extSysAssignedTo;
	private String extSysAssignedGroup;
	private String extSysDescription;
	private String extSysCategory;
	private String extSysSummary;
	private String extSysSubCat;
	private String extSysAssignedSubGrp;
	private String extRecordID;
	private String siglstrength;
	private String devModel;
	private String compTroubleShoooting;
	private String erroMsg;
	private String extSeverity; 
	private String extCustAffect;
	private Date extPlannedRestTime;
	private String callOrigin;
	private String systemUser;
	private String entryType;
	private String engCreatedby;
	private Boolean resolveToSub;
	private String resolveTo;
	private String lastUpdatedBy;

	//RahPay DTT values
	private String extFunctionalArea;
	private String extManagingOrg;
	private String extActiveOrg;
	
	//3 new fields addition...
	private String extSvcLine;
	private Date ExtReqCompletionDate;
	private String extSvcImpact;
	private String engmtCategory;
	private String externalTicketNumber;
	private String extlogSyst;
	private String reportedTroubleDesc;
	
	private String extResCat;
	private String extResType;
	private String extReso;
	private String extResolutionNotes;
	private Date extReturnToServiceTime;
	private String extSectorID;
	private String extAction;  
	private String extQuantity;
	private Date extAlarmTime;
	private Date extProcessTime;
	private String extSysSubCat2;
	
	/********** New field added for mission control   ************/
	
	private String externalSystemName;
	private String externalTicketStatus;
	private String externalSeverity;
	private String externalassetID;
	private String externalSystemDescription;
	private String externalCustomerAffect;
	private String externalSystemCategory;
	private String externalSystemSubCategory;
	private String externalSystemSubCategory2;
	private String externalSystemAssignedGroup;
	private String externalSystemAssignedSubGroup;
	private String compTroubleShooting;
	private String deviceModel;
	private String engagementCreatedby;
	private String errorMessage;
	private String externalPlannedRestoralTime;
	private String externalRecordId;
	private String externalSystemSummary;
	private String resolveToSubmitterIndicator;
	private String signalstrength;
	private String externalResolutionCategory;
	private String externalResolutionType;
	private String externalResolution;
	private String externalResolutionNotes;
	private String engmntRole;
	
	
	public String getExtFunctionalArea() {
		return extFunctionalArea;
	}
	public void setExtFunctionalArea(String extFunctionalArea) {
		this.extFunctionalArea = extFunctionalArea;
	}

	public String getExtManagingOrg() {
		return extManagingOrg;
	}
	public void setExtManagingOrg(String extManagingOrg) {
		this.extManagingOrg = extManagingOrg;
	}
	public String getExtActiveOrg() {
		return extActiveOrg;
	}
	public void setExtActiveOrg(String extActiveOrg) {
		this.extActiveOrg = extActiveOrg;
	}
	public String getTicketNo() {
		return ticketNo;
	}
	public void setTicketNo(String ticketNo) {
		this.ticketNo = ticketNo;
	}
	public String getExtSysName() {
		return extSysName;
	}
	public void setExtSysName(String extSysName) {
		this.extSysName = extSysName;
	}
	public String getExtSystype() {
		return extSystype;
	}
	public void setExtSystype(String extSystype) {
		this.extSystype = extSystype;
	}
	public String getExtTicketNo() {
		return extTicketNo;
	}
	public void setExtTicketNo(String extTicketNo) {
		this.extTicketNo = extTicketNo;
	}
	public String getExtTicketStatus() {
		return extTicketStatus;
	}
	public void setExtTicketStatus(String extTicketStatus) {
		this.extTicketStatus = extTicketStatus;
	}
	public String getEngmtType() {
		return engmtType;
	}
	public void setEngmtType(String engmtType) {
		this.engmtType = engmtType;
	}
	public Date getTicketOpenDate() {
		return ticketOpenDate;
	}
	public void setTicketOpenDate(Date ticketOpenDate) {
		this.ticketOpenDate = ticketOpenDate;
	}
	public Date getLastCommDate() {
		return lastCommDate;
	}
	public void setLastCommDate(Date lastCommDate) {
		this.lastCommDate = lastCommDate;
	}
	public String getLastCommType() {
		return lastCommType;
	}
	public void setLastCommType(String lastCommType) {
		this.lastCommType = lastCommType;
	}
	public String getAssetID() {
		return assetID;
	}
	public void setAssetID(String assetID) {
		this.assetID = assetID;
	}
	public String getAssetType() {
		return assetType;
	}
	public void setAssetType(String assetType) {
		this.assetType = assetType;
	}
	public String getSalesforceAccountID() {
		return salesforceAccountID;
	}
	public void setSalesforceAccountID(String salesforceAccountID) {
		this.salesforceAccountID = salesforceAccountID;
	}
	public String getAccAccountID() {
		return accAccountID;
	}
	public void setAccAccountID(String accAccountID) {
		this.accAccountID = accAccountID;
	}
	public String getExtSysAssignedTo() {
		return extSysAssignedTo;
	}
	public void setExtSysAssignedTo(String extSysAssignedTo) {
		this.extSysAssignedTo = extSysAssignedTo;
	}
	public String getExtSysAssignedGroup() {
		return extSysAssignedGroup;
	}
	public void setExtSysAssignedGroup(String extSysAssignedGroup) {
		this.extSysAssignedGroup = extSysAssignedGroup;
	}
	public String getExtSysDescription() {
		return extSysDescription;
	}
	public void setExtSysDescription(String extSysDescription) {
		this.extSysDescription = extSysDescription;
	}
	public String getExtSysCategory() {
		return extSysCategory;
	}
	public void setExtSysCategory(String extSysCategory) {
		this.extSysCategory = extSysCategory;
	}
	public String getExtSysSummary() {
		return extSysSummary;
	}
	public void setExtSysSummary(String extSysSummary) {
		this.extSysSummary = extSysSummary;
	}
	public String getExtSysSubCat() {
		return extSysSubCat;
	}
	public void setExtSysSubCat(String extSysSubCat) {
		this.extSysSubCat = extSysSubCat;
	}
	public String getExtSysAssignedSubGrp() {
		return extSysAssignedSubGrp;
	}
	public void setExtSysAssignedSubGrp(String extSysAssignedSubGrp) {
		this.extSysAssignedSubGrp = extSysAssignedSubGrp;
	}
	public String getInternalTicket() {
		return internalTicket;
	}
	public void setInternalTicket(String internalTicket) {
		this.internalTicket = internalTicket;
	}
	public String getExtRecordID() {
		return extRecordID;
	}
	public void setExtRecordID(String extRecordID) {
		this.extRecordID = extRecordID;
	}
	public String getSiglstrength() {
		return siglstrength;
	}
	public void setSiglstrength(String siglstrength) {
		this.siglstrength = siglstrength;
	}
	public String getDevModel() {
		return devModel;
	}
	public void setDevModel(String devModel) {
		this.devModel = devModel;
	}
	public String getCompTroubleShoooting() {
		return compTroubleShoooting;
	}
	public void setCompTroubleShoooting(String compTroubleShoooting) {
		this.compTroubleShoooting = compTroubleShoooting;
	}
	public String getErroMsg() {
		return erroMsg;
	}
	public void setErroMsg(String erroMsg) {
		this.erroMsg = erroMsg;
	}
	public String getExtSeverity() {
		return extSeverity;
	}
	public void setExtSeverity(String extSeverity) {
		this.extSeverity = extSeverity;
	}
	public String getExtCustAffect() {
		return extCustAffect;
	}
	public void setExtCustAffect(String extCustAffect) {
		this.extCustAffect = extCustAffect;
	}
	public Date getExtPlannedRestTime() {
		return extPlannedRestTime;
	}
	public void setExtPlannedRestTime(Date extPlannedRestTime) {
		this.extPlannedRestTime = extPlannedRestTime;
	}
	public String getCallOrigin() {
		return callOrigin;
	}
	public void setCallOrigin(String callOrigin) {
		this.callOrigin = callOrigin;
	}
	public String getSystemUser() {
		return systemUser;
	}
	public void setSystemUser(String systemUser) {
		this.systemUser = systemUser;
	}
	public String getEntryType() {
		return entryType;
	}
	public void setEntryType(String entryType) {
		this.entryType = entryType;
	}
	public String getEngCreatedby() {
		return engCreatedby;
	}
	public void setEngCreatedby(String engCreatedby) {
		this.engCreatedby = engCreatedby;
	}
	public Boolean getResolveToSub() {
		return resolveToSub;
	}
	public void setResolveToSub(Boolean resolveToSub) {
		this.resolveToSub = resolveToSub;
	}
	public String getResolveTo() {
		return resolveTo;
	}
	public void setResolveTo(String resolveTo) {
		this.resolveTo = resolveTo;
	}
	public String getExtSvcLine() {
		return extSvcLine;
	}
	public void setExtSvcLine(String extSvcLine) {
		this.extSvcLine = extSvcLine;
	}
	public Date getExtReqCompletionDate() {
		return ExtReqCompletionDate;
	}
	public void setExtReqCompletionDate(Date extReqCompletionDate) {
		ExtReqCompletionDate = extReqCompletionDate;
	}
	public String getExtSvcImpact() {
		return extSvcImpact;
	}
	public void setExtSvcImpact(String extSvcImpact) {
		this.extSvcImpact = extSvcImpact;
	}
	public String getEngmtCategory() {
		return engmtCategory;
	}
	public void setEngmtCategory(String engmtCategory) {
		this.engmtCategory = engmtCategory;
	}
	public String getExternalTicketNumber() {
		return externalTicketNumber;
	}
	public void setExternalTicketNumber(String externalTicketNumber) {
		this.externalTicketNumber = externalTicketNumber;
	}
	public String getExtlogSyst() {
		return extlogSyst;
	}
	public void setExtlogSyst(String extlogSyst) {
		this.extlogSyst = extlogSyst;
	}
	
	
	
	
	
	public String getExternalSystemName() {
		return externalSystemName;
	}
	public void setExternalSystemName(String externalSystemName) {
		this.externalSystemName = externalSystemName;
	}
	public String getExternalTicketStatus() {
		return externalTicketStatus;
	}
	public void setExternalTicketStatus(String externalTicketStatus) {
		this.externalTicketStatus = externalTicketStatus;
	}
	public String getExternalSeverity() {
		return externalSeverity;
	}
	public void setExternalSeverity(String externalSeverity) {
		this.externalSeverity = externalSeverity;
	}
	public String getExternalassetID() {
		return externalassetID;
	}
	public void setExternalassetID(String externalassetID) {
		this.externalassetID = externalassetID;
	}
	public String getExternalSystemDescription() {
		return externalSystemDescription;
	}
	public void setExternalSystemDescription(String externalSystemDescription) {
		this.externalSystemDescription = externalSystemDescription;
	}
	public String getExternalCustomerAffect() {
		return externalCustomerAffect;
	}
	public void setExternalCustomerAffect(String externalCustomerAffect) {
		this.externalCustomerAffect = externalCustomerAffect;
	}
	public String getExternalSystemCategory() {
		return externalSystemCategory;
	}
	public void setExternalSystemCategory(String externalSystemCategory) {
		this.externalSystemCategory = externalSystemCategory;
	}
	public String getExternalSystemSubCategory() {
		return externalSystemSubCategory;
	}
	public void setExternalSystemSubCategory(String externalSystemSubCategory) {
		this.externalSystemSubCategory = externalSystemSubCategory;
	}
	public String getExternalSystemSubCategory2() {
		return externalSystemSubCategory2;
	}
	public void setExternalSystemSubCategory2(String externalSystemSubCategory2) {
		this.externalSystemSubCategory2 = externalSystemSubCategory2;
	}
	public String getExternalSystemAssignedGroup() {
		return externalSystemAssignedGroup;
	}
	public void setExternalSystemAssignedGroup(String externalSystemAssignedGroup) {
		this.externalSystemAssignedGroup = externalSystemAssignedGroup;
	}
	public String getExternalSystemAssignedSubGroup() {
		return externalSystemAssignedSubGroup;
	}
	public void setExternalSystemAssignedSubGroup(String externalSystemAssignedSubGroup) {
		this.externalSystemAssignedSubGroup = externalSystemAssignedSubGroup;
	}
	public String getCompTroubleShooting() {
		return compTroubleShooting;
	}
	public void setCompTroubleShooting(String compTroubleShooting) {
		this.compTroubleShooting = compTroubleShooting;
	}
	public String getDeviceModel() {
		return deviceModel;
	}
	public void setDeviceModel(String deviceModel) {
		this.deviceModel = deviceModel;
	}
	public String getEngagementCreatedby() {
		return engagementCreatedby;
	}
	public void setEngagementCreatedby(String engagementCreatedby) {
		this.engagementCreatedby = engagementCreatedby;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public String getExternalPlannedRestoralTime() {
		return externalPlannedRestoralTime;
	}
	public void setExternalPlannedRestoralTime(String externalPlannedRestoralTime) {
		this.externalPlannedRestoralTime = externalPlannedRestoralTime;
	}
	public String getExternalRecordId() {
		return externalRecordId;
	}
	public void setExternalRecordId(String externalRecordId) {
		this.externalRecordId = externalRecordId;
	}
	public String getExternalSystemSummary() {
		return externalSystemSummary;
	}
	public void setExternalSystemSummary(String externalSystemSummary) {
		this.externalSystemSummary = externalSystemSummary;
	}
	public String getResolveToSubmitterIndicator() {
		return resolveToSubmitterIndicator;
	}
	public void setResolveToSubmitterIndicator(String resolveToSubmitterIndicator) {
		this.resolveToSubmitterIndicator = resolveToSubmitterIndicator;
	}
	public String getSignalstrength() {
		return signalstrength;
	}
	public void setSignalstrength(String signalstrength) {
		this.signalstrength = siglstrength;
	}
	public String getExternalResolutionCategory() {
		return externalResolutionCategory;
	}
	public void setExternalResolutionCategory(String externalResolutionCategory) {
		this.externalResolutionCategory = extResCat;
	}
	public String getExternalResolutionType() {
		return externalResolutionType;
	}
	public void setExternalResolutionType(String externalResolutionType) {
		this.externalResolutionType = extResType;
	}
	public String getExternalResolution() {
		return externalResolution;
	}
	public void setExternalResolution(String externalResolution) {
		this.externalResolution = extReso;
	}
	public String getExternalResolutionNotes() {
		return externalResolutionNotes;
	}
	public void setExternalResolutionNotes(String externalResolutionNotes) {
		this.externalResolutionNotes = extResolutionNotes;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((ExtReqCompletionDate == null) ? 0 : ExtReqCompletionDate.hashCode());
		result = prime * result + ((accAccountID == null) ? 0 : accAccountID.hashCode());
		result = prime * result + ((assetID == null) ? 0 : assetID.hashCode());
		result = prime * result + ((assetType == null) ? 0 : assetType.hashCode());
		result = prime * result + ((callOrigin == null) ? 0 : callOrigin.hashCode());
		result = prime * result + ((compTroubleShoooting == null) ? 0 : compTroubleShoooting.hashCode());
		result = prime * result + ((devModel == null) ? 0 : devModel.hashCode());
		result = prime * result + ((engCreatedby == null) ? 0 : engCreatedby.hashCode());
		result = prime * result + ((engmtCategory == null) ? 0 : engmtCategory.hashCode());
		result = prime * result + ((engmtType == null) ? 0 : engmtType.hashCode());
		result = prime * result + ((entryType == null) ? 0 : entryType.hashCode());
		result = prime * result + ((erroMsg == null) ? 0 : erroMsg.hashCode());
		result = prime * result + ((extActiveOrg == null) ? 0 : extActiveOrg.hashCode());
		result = prime * result + ((extCustAffect == null) ? 0 : extCustAffect.hashCode());
		result = prime * result + ((extFunctionalArea == null) ? 0 : extFunctionalArea.hashCode());
		result = prime * result + ((extManagingOrg == null) ? 0 : extManagingOrg.hashCode());
		result = prime * result + ((extPlannedRestTime == null) ? 0 : extPlannedRestTime.hashCode());
		result = prime * result + ((extRecordID == null) ? 0 : extRecordID.hashCode());
		result = prime * result + ((extSeverity == null) ? 0 : extSeverity.hashCode());
		result = prime * result + ((extSvcImpact == null) ? 0 : extSvcImpact.hashCode());
		result = prime * result + ((extSvcLine == null) ? 0 : extSvcLine.hashCode());
		result = prime * result + ((extSysAssignedGroup == null) ? 0 : extSysAssignedGroup.hashCode());
		result = prime * result + ((extSysAssignedSubGrp == null) ? 0 : extSysAssignedSubGrp.hashCode());
		result = prime * result + ((extSysCategory == null) ? 0 : extSysCategory.hashCode());
		result = prime * result + ((extSysDescription == null) ? 0 : extSysDescription.hashCode());
		result = prime * result + ((extSysName == null) ? 0 : extSysName.hashCode());
		result = prime * result + ((extSysSubCat == null) ? 0 : extSysSubCat.hashCode());
		result = prime * result + ((extSysSummary == null) ? 0 : extSysSummary.hashCode());
		result = prime * result + ((extSystype == null) ? 0 : extSystype.hashCode());
		result = prime * result + ((extTicketNo == null) ? 0 : extTicketNo.hashCode());
		result = prime * result + ((extTicketStatus == null) ? 0 : extTicketStatus.hashCode());
		result = prime * result + ((externalTicketNumber == null) ? 0 : externalTicketNumber.hashCode());
		result = prime * result + ((extlogSyst == null) ? 0 : extlogSyst.hashCode());
		result = prime * result + ((internalTicket == null) ? 0 : internalTicket.hashCode());
		result = prime * result + ((lastCommDate == null) ? 0 : lastCommDate.hashCode());
		result = prime * result + ((lastCommType == null) ? 0 : lastCommType.hashCode());
		result = prime * result + ((resolveTo == null) ? 0 : resolveTo.hashCode());
		result = prime * result + ((resolveToSub == null) ? 0 : resolveToSub.hashCode());
		result = prime * result + ((salesforceAccountID == null) ? 0 : salesforceAccountID.hashCode());
		result = prime * result + ((siglstrength == null) ? 0 : siglstrength.hashCode());
		result = prime * result + ((systemUser == null) ? 0 : systemUser.hashCode());
		result = prime * result + ((ticketNo == null) ? 0 : ticketNo.hashCode());
		result = prime * result + ((ticketOpenDate == null) ? 0 : ticketOpenDate.hashCode());
		
		result = prime * result + ((externalSystemName == null) ? 0 : externalSystemName.hashCode());
		result = prime * result + ((externalTicketStatus == null) ? 0 : externalTicketStatus.hashCode());
		result = prime * result + ((externalSeverity == null) ? 0 : externalSeverity.hashCode());
		result = prime * result + ((externalassetID == null) ? 0 : externalassetID.hashCode());
		result = prime * result + ((externalSystemDescription == null) ? 0 : externalSystemDescription.hashCode());
		result = prime * result + ((externalCustomerAffect == null) ? 0 : externalCustomerAffect.hashCode());
		result = prime * result + ((externalSystemCategory == null) ? 0 : externalSystemCategory.hashCode());
		result = prime * result + ((externalSystemSubCategory == null) ? 0 : externalSystemSubCategory.hashCode());
		result = prime * result + ((externalSystemSubCategory2 == null) ? 0 : externalSystemSubCategory2.hashCode());
		result = prime * result + ((externalSystemAssignedGroup == null) ? 0 : externalSystemAssignedGroup.hashCode());
		result = prime * result + ((externalSystemAssignedSubGroup == null) ? 0 : externalSystemAssignedSubGroup.hashCode());
		result = prime * result + ((compTroubleShooting == null) ? 0 : compTroubleShooting.hashCode());
		result = prime * result + ((deviceModel == null) ? 0 : deviceModel.hashCode());
		result = prime * result + ((engagementCreatedby == null) ? 0 : engagementCreatedby.hashCode());
		result = prime * result + ((errorMessage == null) ? 0 : errorMessage.hashCode());
		result = prime * result + ((externalPlannedRestoralTime == null) ? 0 : externalPlannedRestoralTime.hashCode());
		result = prime * result + ((externalRecordId == null) ? 0 : externalRecordId.hashCode());
		result = prime * result + ((externalSystemSummary == null) ? 0 : externalSystemSummary.hashCode());
		result = prime * result + ((resolveToSubmitterIndicator == null) ? 0 : resolveToSubmitterIndicator.hashCode());
		result = prime * result + ((signalstrength == null) ? 0 : signalstrength.hashCode());
		result = prime * result + ((externalResolutionCategory == null) ? 0 : externalResolutionCategory.hashCode());
		result = prime * result + ((externalResolutionType == null) ? 0 : externalResolutionType.hashCode());
		result = prime * result + ((externalResolution == null) ? 0 : externalResolution.hashCode());
		result = prime * result + ((externalResolutionNotes == null) ? 0 : externalResolutionNotes.hashCode());
		
		
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		VTMEngagment other = (VTMEngagment) obj;
		if (ExtReqCompletionDate == null) {
			if (other.ExtReqCompletionDate != null)
				return false;
		} else if (!ExtReqCompletionDate.equals(other.ExtReqCompletionDate))
			return false;
		if (accAccountID == null) {
			if (other.accAccountID != null)
				return false;
		} else if (!accAccountID.equals(other.accAccountID))
			return false;
		if (assetID == null) {
			if (other.assetID != null)
				return false;
		} else if (!assetID.equals(other.assetID))
			return false;
		if (assetType == null) {
			if (other.assetType != null)
				return false;
		} else if (!assetType.equals(other.assetType))
			return false;
		if (callOrigin == null) {
			if (other.callOrigin != null)
				return false;
		} else if (!callOrigin.equals(other.callOrigin))
			return false;
		if (compTroubleShoooting == null) {
			if (other.compTroubleShoooting != null)
				return false;
		} else if (!compTroubleShoooting.equals(other.compTroubleShoooting))
			return false;
		if (devModel == null) {
			if (other.devModel != null)
				return false;
		} else if (!devModel.equals(other.devModel))
			return false;
		if (engCreatedby == null) {
			if (other.engCreatedby != null)
				return false;
		} else if (!engCreatedby.equals(other.engCreatedby))
			return false;
		if (engmtCategory == null) {
			if (other.engmtCategory != null)
				return false;
		} else if (!engmtCategory.equals(other.engmtCategory))
			return false;
		if (engmtType == null) {
			if (other.engmtType != null)
				return false;
		} else if (!engmtType.equals(other.engmtType))
			return false;
		if (entryType == null) {
			if (other.entryType != null)
				return false;
		} else if (!entryType.equals(other.entryType))
			return false;
		if (erroMsg == null) {
			if (other.erroMsg != null)
				return false;
		} else if (!erroMsg.equals(other.erroMsg))
			return false;
		if (extActiveOrg == null) {
			if (other.extActiveOrg != null)
				return false;
		} else if (!extActiveOrg.equals(other.extActiveOrg))
			return false;
		if (extCustAffect == null) {
			if (other.extCustAffect != null)
				return false;
		} else if (!extCustAffect.equals(other.extCustAffect))
			return false;
		if (extFunctionalArea == null) {
			if (other.extFunctionalArea != null)
				return false;
		} else if (!extFunctionalArea.equals(other.extFunctionalArea))
			return false;
		if (extManagingOrg == null) {
			if (other.extManagingOrg != null)
				return false;
		} else if (!extManagingOrg.equals(other.extManagingOrg))
			return false;
		if (extPlannedRestTime == null) {
			if (other.extPlannedRestTime != null)
				return false;
		} else if (!extPlannedRestTime.equals(other.extPlannedRestTime))
			return false;
		if (extRecordID == null) {
			if (other.extRecordID != null)
				return false;
		} else if (!extRecordID.equals(other.extRecordID))
			return false;
		if (extSeverity == null) {
			if (other.extSeverity != null)
				return false;
		} else if (!extSeverity.equals(other.extSeverity))
			return false;
		if (extSvcImpact == null) {
			if (other.extSvcImpact != null)
				return false;
		} else if (!extSvcImpact.equals(other.extSvcImpact))
			return false;
		if (extSvcLine == null) {
			if (other.extSvcLine != null)
				return false;
		} else if (!extSvcLine.equals(other.extSvcLine))
			return false;
		if (extSysAssignedGroup == null) {
			if (other.extSysAssignedGroup != null)
				return false;
		} else if (!extSysAssignedGroup.equals(other.extSysAssignedGroup))
			return false;
		if (extSysAssignedSubGrp == null) {
			if (other.extSysAssignedSubGrp != null)
				return false;
		} else if (!extSysAssignedSubGrp.equals(other.extSysAssignedSubGrp))
			return false;
		if (extSysCategory == null) {
			if (other.extSysCategory != null)
				return false;
		} else if (!extSysCategory.equals(other.extSysCategory))
			return false;
		if (extSysDescription == null) {
			if (other.extSysDescription != null)
				return false;
		} else if (!extSysDescription.equals(other.extSysDescription))
			return false;
		if (extSysName == null) {
			if (other.extSysName != null)
				return false;
		} else if (!extSysName.equals(other.extSysName))
			return false;
		if (extSysSubCat == null) {
			if (other.extSysSubCat != null)
				return false;
		} else if (!extSysSubCat.equals(other.extSysSubCat))
			return false;
		if (extSysSummary == null) {
			if (other.extSysSummary != null)
				return false;
		} else if (!extSysSummary.equals(other.extSysSummary))
			return false;
		if (extSystype == null) {
			if (other.extSystype != null)
				return false;
		} else if (!extSystype.equals(other.extSystype))
			return false;
		if (extTicketNo == null) {
			if (other.extTicketNo != null)
				return false;
		} else if (!extTicketNo.equals(other.extTicketNo))
			return false;
		if (extTicketStatus == null) {
			if (other.extTicketStatus != null)
				return false;
		} else if (!extTicketStatus.equals(other.extTicketStatus))
			return false;
		if (externalTicketNumber == null) {
			if (other.externalTicketNumber != null)
				return false;
		} else if (!externalTicketNumber.equals(other.externalTicketNumber))
			return false;
		if (extlogSyst == null) {
			if (other.extlogSyst != null)
				return false;
		} else if (!extlogSyst.equals(other.extlogSyst))
			return false;
		if (internalTicket == null) {
			if (other.internalTicket != null)
				return false;
		} else if (!internalTicket.equals(other.internalTicket))
			return false;
		if (lastCommDate == null) {
			if (other.lastCommDate != null)
				return false;
		} else if (!lastCommDate.equals(other.lastCommDate))
			return false;
		if (lastCommType == null) {
			if (other.lastCommType != null)
				return false;
		} else if (!lastCommType.equals(other.lastCommType))
			return false;
		if (resolveTo == null) {
			if (other.resolveTo != null)
				return false;
		} else if (!resolveTo.equals(other.resolveTo))
			return false;
		if (resolveToSub == null) {
			if (other.resolveToSub != null)
				return false;
		} else if (!resolveToSub.equals(other.resolveToSub))
			return false;
		if (salesforceAccountID == null) {
			if (other.salesforceAccountID != null)
				return false;
		} else if (!salesforceAccountID.equals(other.salesforceAccountID))
			return false;
		if (siglstrength == null) {
			if (other.siglstrength != null)
				return false;
		} else if (!siglstrength.equals(other.siglstrength))
			return false;
		if (systemUser == null) {
			if (other.systemUser != null)
				return false;
		} else if (!systemUser.equals(other.systemUser))
			return false;
		if (ticketNo == null) {
			if (other.ticketNo != null)
				return false;
		} else if (!ticketNo.equals(other.ticketNo))
			return false;
		if (ticketOpenDate == null) {
			if (other.ticketOpenDate != null)
				return false;
		} else if (!ticketOpenDate.equals(other.ticketOpenDate)){
			return false;
			

	    }else if (!externalSystemName.equals(other.externalSystemName)){
			return false;
		}else if (!externalTicketStatus.equals(other.externalTicketStatus)){
			return false;
		}else if (!externalSeverity.equals(other.externalSeverity)){
			return false;
		}else if (!externalassetID.equals(other.externalassetID)){
			return false;
		}else if (!externalSystemDescription.equals(other.externalSystemDescription)){
			return false;
		}else if (!externalCustomerAffect.equals(other.externalCustomerAffect)){
			return false;
		}else if (!externalSystemCategory.equals(other.externalSystemCategory)){
			return false;
		}else if (!externalSystemSubCategory.equals(other.externalSystemSubCategory)){
			return false;
		}else if (!externalSystemSubCategory2.equals(other.externalSystemSubCategory2)){
			return false;
		}else if (!externalSystemAssignedGroup.equals(other.externalSystemAssignedGroup)){
			return false;
		}else if (!externalSystemAssignedSubGroup.equals(other.externalSystemAssignedSubGroup)){
			return false;
		}else if (!compTroubleShooting.equals(other.compTroubleShooting)){
			return false;
		}else if (!engagementCreatedby.equals(other.engagementCreatedby)){
			return false;
		}else if (!errorMessage.equals(other.errorMessage)){
			return false;
		}else if (!externalPlannedRestoralTime.equals(other.externalPlannedRestoralTime)){
			return false;
		}else if (!externalRecordId.equals(other.externalRecordId)){
			return false;
		}else if (!externalSystemSummary.equals(other.externalSystemSummary)){
			return false;
		}else if (!resolveToSubmitterIndicator.equals(other.resolveToSubmitterIndicator)){
			return false;
		}else if (!signalstrength.equals(other.signalstrength)){
			return false;
		}else if (!externalResolutionCategory.equals(other.externalResolutionCategory)){
			return false;
		}else if (!externalResolutionType.equals(other.externalResolutionType)){
			return false;
		}else if (!externalResolution.equals(other.externalResolution)){
			return false;
		}else if (!externalResolutionNotes.equals(other.externalResolutionNotes)){
			return false;
		}
		
		return true;
	}

	public String getReportedTroubleDesc() {
		return reportedTroubleDesc;
	}
	public void setReportedTroubleDesc(String reportedTroubleDesc) {
		this.reportedTroubleDesc = reportedTroubleDesc;
	}

	public String getExtResCat() {
		return extResCat;
	}
	public void setExtResCat(String extResCat) {
		this.extResCat = extResCat;
	}

	public String getExtResType() {
		return extResType;
	}
	public void setExtResType(String extResType) {
		this.extResType = extResType;
	}

	public String getExtReso() {
		return extReso;
	}
	public void setExtReso(String extReso) {
		this.extReso = extReso;
	}

	public String getExtResolutionNotes() {
		return extResolutionNotes;
	}
	public void setExtResolutionNotes(String extResolutionNotes) {
		this.extResolutionNotes = extResolutionNotes;
	}
	public Date getExtReturnToServiceTime() {
		return extReturnToServiceTime;
	}
	public void setExtReturnToServiceTime(Date xmlGregorianCalendar) {
		this.extReturnToServiceTime = xmlGregorianCalendar;
	}
	public String getExtSectorID() {
		return extSectorID;
	}
	public void setExtSectorID(String extSectorID) {
		this.extSectorID = extSectorID;
	}
	public String getExtAction() {
		return extAction;
	}
	public void setExtAction(String extAction) {
		this.extAction = extAction;
	}
	public String getExtQuantity() {
		return extQuantity;
	}
	public void setExtQuantity(String extQuantity) {
		this.extQuantity = extQuantity;
	}
	public Date getExtAlarmTime() {
		return extAlarmTime;
	}
	public void setExtAlarmTime(Date extAlarmTime) {
		this.extAlarmTime = extAlarmTime;
	}
	public Date getExtProcessTime() {
		return extProcessTime;
	}
	public void setExtProcessTime(Date extProcessTime) {
		this.extProcessTime = extProcessTime;
	}
	public String getExtSysSubCat2() {
		return extSysSubCat2;
	}
	public void setExtSysSubCat2(String extSysSubCat2) {
		this.extSysSubCat2 = extSysSubCat2;
	}
	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}
	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}
	public String getEngmntRole() {
		return engmntRole;
	}
	public void setEngmntRole(String engmntRole) {
		this.engmntRole = engmntRole;
	}	
	
}
