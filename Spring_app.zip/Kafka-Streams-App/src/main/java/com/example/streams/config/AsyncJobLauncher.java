package com.example.streams.config;

import java.sql.Date;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.example.streams.dto.Ticket;

@EnableAsync
@EnableScheduling
@Component
public class AsyncJobLauncher {/*
	private static Logger logger = Logger.getLogger(AsyncJobLauncher.class);
	
	@Autowired
	private ThreadPoolTaskScheduler scheduler;
	
	//public static String url = "http://wiwauk4coldfw02.itservices.sbc.com:82/one/testing/2018_10_Release_Vince/services/OneAPI.cfc";
	
	//@Autowired
	//RestTemplate restTemplate;

	
	int delayToLaunchJob;

	public Runnable scheduleJob(Ticket ticket) {

		Runnable executeBatch = new Runnable() {
			@Override
			public void run() {
			
				try {
					Instant ld = Instant.now();
//					System.out.println("starting sleep thread Name>>>>"+Thread.currentThread().getName() + " processing item:"+i + " at:"+ld);
					Thread.sleep(10000);
					
										
					Map<String, String> uriVariables = new HashMap<String,String>();
					uriVariables.put("method", "sendCallToWork");
					uriVariables.put("faID", "10");
					uriVariables.put("faName","Mobility");
					uriVariables.put("groupName", "GTOC_UNOC_RC-TEST");
					uriVariables.put("attuid", "m12457");
					uriVariables.put("returnIncident", "1");
					uriVariables.put("assignBridge", "1");
					uriVariables.put("subject", "Mobility C2W");
					uriVariables.put("shortDescription", "{\"eventType\":\"<eventType>\", \"createdBy\":\"< createdBy >\", \"vTMTicketNumber\":\"< ticketNo >\"}");
					uriVariables.put("severity", "4");
//					uriVariables.put("method", value);
					
					
//					restTemplate.postForObject(url, request, responseType, uriVariables);
					ld = Instant.now();
//					System.out.println("woekn up thread Name>>>>"+Thread.currentThread().getName()+ " processing item:"+i + " at:"+ld);
				} catch (Exception e) {
					
				}
			}
		};
		return executeBatch;

	}

	@Async
	public void executeTaskT(int i, int delayInMinutes) {
		try {

//			scheduler.schedule(scheduleJob(i),
//					new Date(System.currentTimeMillis() + delayInMinutes * 30 * 1000));
			
			Map<Thread, StackTraceElement[]> threads = Thread.getAllStackTraces();
		
		} catch (Exception e) {
			// e.printStackTrace();
			logger.error("Error while launching task executor:" + e);
		}
	}

*/}
