package com.example.streams.dto;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

//@XmlAccessorType(XmlAccessType.FIELD)
//@XmlRootElement(name = "ticketResolution")
public class TicketResolution implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String resolutionSetName;
	
	private String srvImpact;
	
	private String reqType;
	
	private String srvLn;
	
	private String prd;
	
	private String srvComp;
	
	private String action;
	
	private String item;
	
	private String rC;
	
	private String sRC;
	
	private String fa;
	
	private String resolnText;
	
	private String clientSatisfied;
	
	private String billingIndicator;
	
	private String resolnItem;
	
	public String getClientSatisfied() {
		return clientSatisfied;
	}

	public void setClientSatisfied(String clientSatisfied) {
		this.clientSatisfied = clientSatisfied;
	}

	public String getBillingIndicator() {
		return billingIndicator;
	}

	public void setBillingIndicator(String billingIndicator) {
		this.billingIndicator = billingIndicator;
	}


	public String getSrvImpact() {
		return srvImpact;
	}

	public void setSrvImpact(String srvImpact) {
		this.srvImpact = srvImpact;
	}

	public String getReqType() {
		return reqType;
	}

	public void setReqType(String reqType) {
		this.reqType = reqType;
	}

	public String getSrvLn() {
		return srvLn;
	}

	public void setSrvLn(String srvLn) {
		this.srvLn = srvLn;
	}

	public String getPrd() {
		return prd;
	}

	public void setPrd(String prd) {
		this.prd = prd;
	}

	public String getSrvComp() {
		return srvComp;
	}

	public void setSrvComp(String srvComp) {
		this.srvComp = srvComp;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getItem() {
		return item;
	}

	public void setItem(String item) {
		this.item = item;
	}

	public String getrC() {
		return rC;
	}

	public void setrC(String rC) {
		this.rC = rC;
	}

	public String getsRC() {
		return sRC;
	}

	public void setsRC(String sRC) {
		this.sRC = sRC;
	}

	public String getFa() {
		return fa;
	}

	public void setFa(String fa) {
		this.fa = fa;
	}

	public String getResolnText() {
		return resolnText;
	}

	public void setResolnText(String resolnText) {
		this.resolnText = resolnText;
	}

	public String getResolutionSetName() {
		return resolutionSetName;
	}

	public void setResolutionSetName(String resolutionSetName) {
		this.resolutionSetName = resolutionSetName;
	}

	public String getResolnItem() {
		return resolnItem;
	}

	public void setResolnItem(String resolnItem) {
		this.resolnItem = resolnItem;
	}
	
}
